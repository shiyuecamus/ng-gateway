import{aI as o}from"./bootstrap-DxuVPH2y.js";import{bl as t,M as a}from"../jse/index-index-D4Oxp58A.js";const r=()=>{const e=t(!1);return a(()=>{e.value=o()}),e};export{r as u};
