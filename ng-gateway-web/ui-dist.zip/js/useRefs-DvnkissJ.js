import{b9 as o,K as r}from"../jse/index-index-D4Oxp58A.js";const f=()=>{const e=o(new Map),s=t=>a=>{e.value.set(t,a)};return r(()=>{e.value=new Map}),[s,e]};export{f as u};
