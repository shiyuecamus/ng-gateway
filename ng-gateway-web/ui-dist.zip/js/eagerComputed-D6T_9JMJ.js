import{bl as s,bF as a}from"../jse/index-index-D4Oxp58A.js";function r(t){const e=s();return a(()=>{e.value=t()},{flush:"sync"}),e}export{r as e};
