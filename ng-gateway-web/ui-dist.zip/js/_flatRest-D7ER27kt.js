import{j as n,s,o}from"./hasIn-DlZ7AZw0.js";function l(t){var e=t==null?0:t.length;return e?n(t):[]}function r(t){return s(o(t,void 0,l),t+"")}export{r as f};
