import{az as t}from"./bootstrap-DxuVPH2y.js";var o=t(Object.getPrototypeOf,Object);export{o as g};
