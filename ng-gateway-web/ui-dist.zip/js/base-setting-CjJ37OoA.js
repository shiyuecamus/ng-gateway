import{_ as o}from"./base-setting.vue_vue_type_script_setup_true_lang-CTwBHCFx.js";import"./bootstrap-DxuVPH2y.js";import"../jse/index-index-D4Oxp58A.js";export{o as default};
